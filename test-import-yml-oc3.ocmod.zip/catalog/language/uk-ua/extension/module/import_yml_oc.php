<?php

$_['error_no_token'] = 'помилка no token';
$_['error_status'] = 'помилка status';
$_['error_template_data'] = 'помилка template_data';
$_['error_no_odmproyml_update_yml_link'] = 'помилка no odmproyml_update_yml_link';
$_['entry_identificator_empty'] = 'помилка entry_identificator_empty';
$_['entry_type_change_new_data'] = 'помилка entry_type_change_new_data';
$_['entry_product_required_empty'] = 'помилка entry_product_required_empty';
$_['entry_category_required_empty'] = 'помилка entry_category_required_empty';
$_['entry_attribute_or_filter_group_empty'] = 'помилка entry_attribute_or_filter_group_empty';
$_['text_type_data_attribute_or_filter'] = 'помилка text_type_data_attribute_or_filter';
$_['entry_curl_exits'] = 'помилка entry_curl_exits';
$_['entry_file_exits'] = 'помилка entry_file_exits';
$_['import_success_accomplished'] = 'успіх імпорту досягнутий';