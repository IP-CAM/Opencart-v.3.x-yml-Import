<?php

$_['error_no_token'] = 'error no token';
$_['error_status'] = 'error status';
$_['error_template_data'] = 'error template_data';
$_['error_no_odmproyml_update_yml_link'] = 'error no odmproyml_update_yml_link';
$_['entry_identificator_empty'] = 'error entry_identificator_empty';
$_['entry_type_change_new_data'] = 'error entry_type_change_new_data';
$_['entry_product_required_empty'] = 'error entry_product_required_empty';
$_['entry_category_required_empty'] = 'error entry_category_required_empty';
$_['entry_attribute_or_filter_group_empty'] = 'error entry_attribute_or_filter_group_empty';
$_['text_type_data_attribute_or_filter'] = 'error text_type_data_attribute_or_filter';
$_['entry_curl_exits'] = 'error entry_curl_exits';
$_['entry_file_exits'] = 'error entry_file_exits';
$_['import_success_accomplished'] = 'import_success_accomplished';
